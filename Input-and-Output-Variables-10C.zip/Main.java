class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
  }
}
/*This is a comment*/ 
//This is another way to comment 
/* Java Variable types 
You have 5 TYPES OF VARIABLES IN Java 
Boolean: True/False, only 2 state - boolean  
Integers: Int, always WHOLE number 
Strings: Text, ex "Hello"
Floats: Decimals, ex 19.99 or -19.99 
Char: Single characters, "a", "B", WRITE A CODE THAT GIVES YOU HOW MANY CHARACTERS ARE IN "Pneumonoultramicroscopicsilicovolcanoconiosis"


In math x = 4 means 4 = x
In programming x = 4 (4 is assigned to x)

x= "patty"
b= "Tomato"
c= "Cheese"
d= "Bread"
e= "Lettuce"
f= "Ketchup"
g= "Mayo"

So the template is: type variable = value;
*/
